// Controller for admin app

import { getCategories, getAllProducts, addProduct, getProductsByCategory, adminLogin, updateProduct, deleteProduct, getAllOrders, deleteOrder} from "../api_service.mjs";
import { CategoryView, ProductForm, ProductView } from "./views/admin_product_views.mjs";
import { OrderView } from "./views/admin_order_views.mjs";
import { UserView } from "./views/admin_user_views.mjs";
import { ReviewView } from "./views/admin_review_views.mjs";
import { showMessage } from "../msg_handler.mjs";

//init -------------------------------------------
const catView = new CategoryView();
const prodView = new ProductView();
const prodForm = new ProductForm();
const orderView = new OrderView();
const userView = new UserView();
const reviewView = new ReviewView();

const viewMap = {
    "catview": catView,
    "prodview": prodView,
    "prodform": prodForm,
    "orderview": orderView,
    "userview": userView,
    "reviewview": reviewView
}
const viewContainer = document.getElementById("viewContainer");
const btnAddProd = document.getElementById('btnAddProd');
const btnHome = document.getElementById('btnHome');
const btnLogin = document.getElementById("btnLogin");
const adminNav = document.getElementById("adminNav");
const adminLoginForm = document.getElementById("adminLoginForm");
const btnProducts = document.getElementById("btnProducts");
const btnOrders = document.getElementById("btnOrders");
const btnUsers = document.getElementById("btnUsers");
const btnReviews = document.getElementById("btnReviews");



//------------------------------------------------
function navigateTo(viewName) {
    viewContainer.replaceChildren();
    viewContainer.appendChild(viewMap[viewName]);
}

//------------------------------------------------
catView.addEventListener('categoryselect', async function (evt) {
    const categoryId = evt.categoryData.id;
    const products = await getProductsByCategory(categoryId);
    prodView.refresh(products);
    navigateTo("prodview");
});

//------------------------------------------------
prodForm.addEventListener('addproduct', async function (evt) {
    const result = await addProduct(evt.productForm);
    if (result) {
        prodForm.resetForm()
        showMessage("Product added successfully!");
    }else {
    showMessage("Could not add product. Please try again.");
}
});

prodForm.addEventListener("updateproduct", async function (evt) {
    const result = await updateProduct(evt.productForm);
    if (result) {
        showMessage("Product updated successfully!");
        btnProducts.click();
    }else {
    showMessage("Could not edit product. Please try again.");
}
});

prodForm.addEventListener('canceladdproduct', function (evt) {
    btnProducts.click();
});

//-------------------Admin logIn-----------------------------

btnLogin.addEventListener('click', async function (evt) {
    const username = document.getElementById("uname").value;
    const password = document.getElementById("psw").value;
    const loginData = await adminLogin(username, password);

    if (loginData && loginData.logindata.token) {
        sessionStorage.setItem("adminToken", loginData.logindata.token);
        adminNav.hidden = false;
        adminLoginForm.hidden = true;
        btnProducts.click(); // Navigate to products view after successful login
    } else {
        showMessage("Could not log in. Please try again.")  
    }
});

//-------------------navigation-----------------------------

btnProducts.addEventListener('click', async function (evt) {
    const products = await getAllProducts();
    prodView.refresh(products);
    navigateTo("prodview");
    setActiveTab(btnProducts);

});

btnOrders.addEventListener('click', async function (evt) {
   
    const orders = await getAllOrders();

    orderView.refresh(orders); 

    navigateTo("orderview");
    setActiveTab(btnOrders);
    
});

btnUsers.addEventListener('click', function (evt) {
    navigateTo("userview");
    setActiveTab(btnUsers);
});

btnReviews.addEventListener('click', function (evt) {
    navigateTo("reviewview");
    setActiveTab(btnReviews);
});

function setActiveTab(selectedButton) {
    adminNav.querySelectorAll("button").forEach(button => {
        button.classList.remove("active");
    });
    selectedButton.classList.add("active");
};

prodView.addEventListener("showaddproduct", function (evt) {
    prodForm.prepareAdd();
    navigateTo("prodform");
});
prodView.addEventListener("editproduct", function (evt) {
    prodForm.prepareEdit(evt.detail);
    navigateTo("prodform");
});

prodView.addEventListener("deleteproduct", async function (evt) {
    const product = evt.detail;
    const confirm = window.confirm(
        "Are you sure you want to delete " + product.name + "?"
    );
    if (!confirm) {
        return;
    }
    const result = await deleteProduct(product.id);
    if (result) {
        showMessage("Product deleted successfully!");
        btnProducts.click();
    }else {
    showMessage("Could not delete product. Please try again.");
}
});

orderView.addEventListener("deleteorder", async function (evt) {
    const order = evt.detail;
    const confirm = window.confirm(
        "Are you sure you want to delete " + order.id + "?"
    );
    if (!confirm) {
        return;
    }
    const result = await deleteOrder(order.id);
    if (result) {
        showMessage("Order deleted successfully!");
        btnOrders.click();
    }else {
    showMessage("Could not delete order. Please try again.");
}
});